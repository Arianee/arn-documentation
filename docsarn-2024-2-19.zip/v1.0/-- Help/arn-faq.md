---
title: "FAQ"
slug: "arn-faq"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 09 2023 14:54:25 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Sep 04 2023 09:19:29 GMT+0000 (Coordinated Universal Time)"
---
### Is ARN useful only for Arianee NFT?

Not only. You can use ARN to [connect any wallet of your users](doc:arn-client-authentication) or [to perform ERC 721 token gating](doc:condition-arn-client-erc-721-condition-api), for instance.

***

### Can I use ARN with any JavaScript framework?

Yes, as ARN client libraries are written in pure vanilla TypeScript. You just have to include its libraries in your project and call the API, and/or include the [ARN tags](doc:arn-components-introduction) in your web pages. 

***

### Is ARN a Wallet Connect wrapper?

It is way more than that. ARN allows you to connect users to your dApp using Wallet Connect and Web3Modal. This will create an ARN authentication context that will allow you to connect to an ARN server to benefit from more services such as token gating, lists, data access, conditions, etc.

***

### Is an ARN server multi-tenant or multi-instance?

It can be both. An ARN server can host multiple ARN projects, or a project can use its dedicated server.

***

### Where is ARN data stored?

There are two kinds of data used by ARN:

- [Configuration](doc:arn-server-configuration), which is stored in a MongoDB database associated with its project/server.
- [Project Data](doc:arn-server-data), which is stored wherever the project wants it to be (currently limited to a MongoDB URL). This is typically where you could store lists of allowed wallets or other token-gating settings, translations, feature flags, or whatever you’d like to store.

***

### What about ARN security?

ARN remote services are controlled by Access Control List (ACL) by design and per project. Each call has default allowed profiles but any of them can be fine-tuned in the [server configuration](doc:arn-server-introduction) to be less or more restrictive.

***

### What about ARN performance?

ARN has been tested to support running complex scenarios (connection + token gating) over 12000+ concurrent users.

### Can I see examples of ARN projects?

Yes, you can check <a href="https://github.com/Arianee/arn-example" target="_blank">ARN example</a> repository for simple bootstraps of ARN projects using the tech stack of choice, or ask Arianee about ARN projects already in production.  

***

### How can I administrate my ARN project?

You can use <a href="https://arn-admin.arianee.com/" target="_blank">ARN Admin</a> to create and administrate projects. 

***

### Where is my ARN Server?

Depending on what you want to do (testing or building a real project), you can either create a test project on the <a href="https://arn-server-test-prod.arianee.com" target="_blank">ARN test server</a> or request Arianee to create a dedicated server for you.

***

### What are the libraries used by ARN Client?

_Note that only significant versions are indicated, intermediate versions have no libs changes._

[block:parameters]
{
  "data": {
    "h-0": "<a href=\"https://www.npmjs.com/package/@arianee/arn-client\" target=\"_blank\">arn-client</a>",
    "h-1": "<a href=\"https://web3modal.com/\" target=\"_blank\">Web3Modal</a>",
    "h-2": "<a href=\"https://ethers.org/\" target=\"_blank\">ethers</a>",
    "h-3": "<a href=\"https://wagmi.sh/\" target=\"_blank\">wagmi</a>",
    "h-4": "<a href=\"https://viem.sh/\" target=\"_blank\">viem</a>",
    "h-5": "Description",
    "0-0": "<a href=\"https://www.npmjs.com/package/@arianee/arn-client/v/2.2.13?activeTab=versions\" target=\"_blank\">2.2.13</a>",
    "0-1": "<a href=\"https://github.com/WalletConnect/web3modal/tree/V2\" target=\"_blank\">2.4.0</a>",
    "0-2": "<a href=\"https://docs.ethers.org/v6\" target=\"_blank\">6.0</a>",
    "0-3": "1.0.6",
    "0-4": "0.3.50",
    "0-5": "-",
    "1-0": "<a href=\"https://www.npmjs.com/package/@arianee/arn-client/v/2.2.10\" target=\"_blank\">2.2.10</a>",
    "1-1": "<a href=\"https://github.com/WalletConnect/web3modal/tree/V2\" target=\"_blank\">2.4.0</a>",
    "1-2": "<a href=\"https://docs.ethers.org/v6\" target=\"_blank\">6.0</a>",
    "1-3": "1.0.6",
    "1-4": "0.3.50",
    "1-5": "Removed dependency to process",
    "2-0": "<a href=\"https://www.npmjs.com/package/@arianee/arn-client/v/2.2.7\" target=\"_blank\">2.2.7</a>",
    "2-1": "<a href=\"https://github.com/WalletConnect/web3modal/tree/V2\" target=\"_blank\">2.4.0</a>",
    "2-2": "<a href=\"https://docs.ethers.org/v6\" target=\"_blank\">6.0</a>",
    "2-3": "1.0.6",
    "2-4": "0.3.50",
    "2-5": "Removed Web3Modal V1 support",
    "3-0": "<a href=\"https://www.npmjs.com/package/@arianee/arn-client/v/2.2.2\" target=\"_blank\">2.2.2</a>",
    "3-1": "<a href=\"https://github.com/WalletConnect/web3modal/tree/V1\" target=\"_blank\">1.9.12</a>  \n<a href=\"https://github.com/WalletConnect/web3modal/tree/V2\" target=\"_blank\">2.7.1</a>",
    "3-2": "<a href=\"https://docs.ethers.org/v6\" target=\"_blank\">6.0</a>",
    "3-3": "1.3.8",
    "3-4": "1.5.3",
    "3-5": "TypeScript 5 version with Web3Modal V2.7 support",
    "4-0": "<a href=\"https://www.npmjs.com/package/@arianee/arn-client/v/2.2.1\" target=\"_blank\">2.2.1</a>",
    "4-1": "<a href=\"https://github.com/WalletConnect/web3modal/tree/V1\" target=\"_blank\">1.9.12</a>  \n<a href=\"https://github.com/WalletConnect/web3modal/tree/V2\" target=\"_blank\">2.4.0</a>",
    "4-2": "<a href=\"https://docs.ethers.org/v6\" target=\"_blank\">6.0</a>",
    "4-3": "1.0.6",
    "4-4": "0.3.50",
    "4-5": "Web3Modal V2.4 support",
    "5-0": "<a href=\"https://www.npmjs.com/package/@arianee/arn-client/v/2.0.0\" target=\"_blank\">2.0.0</a>",
    "5-1": "<a href=\"https://github.com/WalletConnect/web3modal/tree/V1\" target=\"_blank\">1.9.12</a>  \n<a href=\"https://github.com/WalletConnect/web3modal/tree/V2\" target=\"_blank\">2.2.0</a>",
    "5-2": "<a href=\"https://docs.ethers.org/v5\" target=\"_blank\">5.7.12</a>",
    "5-3": "0.10.16",
    "5-4": "-",
    "5-5": "-"
  },
  "cols": 6,
  "rows": 6,
  "align": [
    null,
    null,
    null,
    null,
    null,
    null
  ]
}
[/block]


| arn-client                                                                                    | <a href="https://www.typescriptlang.org/" target="_blank">Typescript</a> |
| --------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------ |
| <a href="https://www.npmjs.com/package/@arianee/arn-client/v/2.2.7" target="_blank">2.2.7</a> | 4.9.4                                                                    |
| <a href="https://www.npmjs.com/package/@arianee/arn-client/v/2.2.2" target="_blank">2.2.2</a> | 5.0.4                                                                    |
| <a href="https://www.npmjs.com/package/@arianee/arn-client/v/2.2.1" target="_blank">2.2.1</a> | 4.9.4                                                                    |
| <a href="https://www.npmjs.com/package/@arianee/arn-client/v/2.0.0" target="_blank">2.2.0</a> | 4.9.5                                                                    |
