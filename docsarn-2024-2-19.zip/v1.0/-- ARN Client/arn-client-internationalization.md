---
title: "Internationalization"
slug: "arn-client-internationalization"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 09 2023 15:14:51 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Sep 07 2023 08:12:13 GMT+0000 (Coordinated Universal Time)"
---
The ARN Client provides the capability to fetch translations from the ARN Server. Once the ARN Client is initialized, the translation service is exposed through the `i18n` property of the `arnClient` object.

## Configuration

The configuration of the translation service is specified in the `i18n` section of the ARN Client configuration. The properties available in this section are as follows:

- `url`: The URL from which translations are fetched. Leaving this empty will utilize the default URL provided by your ARN Server's i18n endpoint. Alternatively, you can specify a custom URL, either relative or absolute.
- `lang`: An array of allowed language codes. For example, `['fr', 'en']` specifies that only French and English translations are allowed.
- `defaultLang`: The default language code to use if the client's language is not detected. For example, `'fr'` specifies French as the default language.

By default, the ARN Client detects the values for these properties.

## Fetching Translations

Translations are organized as a branch of your ARN data. Before fetching translations, ensure that:

- The data storage for translations is properly configured. Refer to the [ARN Server Internationalization Service](doc:arn-server-internationalization) for configuration details.
- Your translations are stored appropriately. Refer to the same documentation for information on storing translations.

To request translations, you can use the i18n client API provided by the ARN Client. The primary method for fetching translations is `get()`. Here's an example of how to use it:

```javascript
translations = await arnClient.i18n.get(path)
```

For instance:

- `arnClient.i18n.get("fr")` will retrieve translations for the French language.
- `arnClient.i18n.get()` will retrieve translations for the client's detected language.
- `arnClient.i18n.get("it/myLoginPage")` will retrieve Italian translations for the `myLoginPage` sub-branch of translations, focusing on the translations specific to that page.

## Typing

If you want to type your translations for better code completion and type safety, you can specify a TypeScript interface during the retrieval call. Here's an example:

```javascript
interface MyTranslations {  
  welcome: string
  myLoginPage: {
    enterPassword: string
  }
}

const translations = await arnClient.i18n.get<MyTranslations>()
console.log(translations.myLoginPage.enterPassword)
```

In the above example, the `MyTranslations` interface defines the structure of the translation object. By passing `MyTranslations` as the generic type argument to the `get()` method, the returned translations will be automatically typed according to the interface, enabling you to access nested properties with proper typing.
