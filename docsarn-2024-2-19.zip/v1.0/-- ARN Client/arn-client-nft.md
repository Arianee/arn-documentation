---
title: "NFT"
slug: "arn-client-nft"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 09 2023 15:13:36 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Sep 07 2023 08:05:52 GMT+0000 (Coordinated Universal Time)"
---
Once initialized, the ARN Client API expose its `[ArnNftService](https://arianee.github.io/arn/packages/arn-client/docs/interfaces/ArnConditionService.html)` through:

```tsx
arnClient.**nft**
```

This service features specialized sub-APIs:

- `nft.**erc721**` to gather info about a standard NFT
- `nft.**erc721a**` to collect NFTs using that later standard
- `nft.**arianee**` to find Arianee Smart Assets.

## Getting ERC-721 Metadata

Since 1.43.0, you can fetch for Arianee NFTs (a.k.a. “Arianee Smart Assets”) owned by the _connected_ user using `[getList()](https://arianee.github.io/arn/packages/arn-client/docs/interfaces/ArnNftService.html#getList)`, optionally with a tag filter:

```javascript
const searchCriteria = {
  contractAddress: '0x776d77485578e703131b66ef50b1d77f225cc478'
  tokenId: 60,
  chainId: 1  // Ethereum
}
const nftMetadata = await arnClient.nft.**erc721**.getToken(searchCriteria);
```

Results will be provided as an `ArnNftMetadata`.

## Finding ERC-721A tokens

Since 1.43.0, you can search for NFTs from a given contract and chain, as owned by a given user (currently connected user by default):

```javascript
const searchCriteria = {
  contractAddress: '0x776d77485578e703131b66ef50b1d77f225cc478'
  chainId: 1  // Ethereum
}
const ownedNFTs = await arnClient.nft.**erc721a**.getTokenList(searchCriteria);
const count = ownedNFTs.length;
if (count > 0) {
  console.log(`The connected user owns ${count} NFTs of the required contract: `, ownedNFTs);
} else {
  console.log(`The connected user does not own any NFTs of the required contract`);
}
```

Results will be provided as an array of `ArnNftMetadata`.

## Getting Arianee NFTs

Since 1.35.2, you can query for Arianee NFTs (a.k.a. “Arianee Smart Assets”) owned by the _connected_ user using `[getList()](https://arianee.github.io/arn/packages/arn-client/docs/interfaces/ArnNftService.html#getList)`, with the following parameters:

- `**filter**` - optional
  - `tags` - For example, if you include `tags: ['tag1', ‘tag2’]`, the search will return NFTs with either ‘tag1’ or ‘tag2’.
  - `arianeeEvents` - optional
    - `eventType` - optional
    - `title` - optional
    - `valuePrice` - optional
    - `location` - optional
- `**projection**` - optional. By default, the `nftDetail` information is not retrieved. You can specify what you intend to retrieve by setting a `projection`.
  - (blockchain) `events`, default value = `false`
  - `arianeeEvents`, default value = `false`
  - `content`, default value = `true`

For instance:

```javascript
const nftsWithThatTag = await arnClient.nft.**arianee**.getList(
{
   filter:{ // NFTs should fulfill tags conditions **AND** arianeeEvents conditions
      tags:[ // NFTs should have tag *public_v2* **OR** *test-multichain*
         'public_v2',      
         'test-multichain'
      ],
			arianeeEvents:{ // NFTs should have eventType as *repair* **AND** title as *Repair enregistrement*
         eventType: 'repair',
         title: 'Repair enregistrement'
       }
   },
   projection:{  
      content:true,   // Retrieve nftDetail -> content data
      arianeeEvents:true,  // Retrieve nftDetail -> events -> arianeeEvents data
      events:true. // Retrieve nftDetail -> events -> (blockchain) transfer data
   }
}
);
const allArianeeNftsOwnedByThisUser = await arnClient.nft.**arianee**.getList();
```

Results will be provided as an array of [`NmpGetCertificateResponse`](https://arianee.github.io/arn/packages/arn-types/docs/interfaces/NmpGetCertificatesResponse.html).

The ARN Client API exposes the [`ArnNftService`](https://arianee.github.io/arn/packages/arn-client/docs/interfaces/ArnConditionService.html) through the `arnClient.nft` property. This service provides specialized sub-APIs for interacting with different types of NFTs.

## ERC-721 API

The `nft.erc721` API allows you to gather information about standard ERC721 NFTs. You can use the following methods:

- `getToken(searchCriteria)`: Fetches Arianee NFTs (Arianee Smart Assets) owned by the connected user, optionally with a tag filter. The `searchCriteria` parameter is an object that specifies the search criteria, including the contract address, token ID, and chain ID. The method returns an `ArnNftMetadata` object.

Example usage:

```javascript
const searchCriteria = {
  contractAddress: '0x776d77485578e703131b66ef50b1d77f225cc478',
  tokenId: 60,
  chainId: 1 // Ethereum
};
const nftMetadata = await arnClient.nft.erc721.getToken(searchCriteria);
```

## ERC-721A API

The `nft.erc721a` API allows you to collect NFTs using the ERC721A standard. You can search for NFTs from a given contract and chain owned by a specific user. The default user is the currently connected user. The following method is available:

- `getTokenList(searchCriteria)`: Searches for NFTs based on the specified search criteria. The `searchCriteria` parameter is an object that includes the contract address and chain ID. The method returns an array of `ArnNftMetadata` objects.

Example usage:

```javascript
const searchCriteria = {
  contractAddress: '0x776d77485578e703131b66ef50b1d77f225cc478',
  chainId: 1 // Ethereum
};
const ownedNFTs = await arnClient.nft.erc721a.getTokenList(searchCriteria);
const count = ownedNFTs.length;
if (count > 0) {
  console.log(`The connected user owns ${count} NFTs of the required contract: `, ownedNFTs);
} else {
  console.log(`The connected user does not own any NFTs of the required contract`);
}
```

## Arianee API

The `nft.arianee` API allows you to find Arianee NFTs (Arianee Smart Assets) owned by the connected user. It provides the following methods:

- `getList(filter?, projection?)`: Queries Arianee NFTs owned by the connected user based on the specified filter and projection parameters. The `filter` parameter allows you to define tag conditions and Arianee event conditions. The `projection` parameter specifies the data to retrieve. The method returns an array of `NmpGetCertificateResponse` objects.

Example usage:

```javascript
const nftsWithThatTag = await arnClient.nft.arianee.getList({
  filter: {
    tags: ['public_v2', 'test-multichain'],
    arianeeEvents: {
      eventType: 'repair',
      title: 'Repair enregistrement'
    }
  },
  projection: {
    content: true,
    arianeeEvents: true,
    events: true
  }
});

const allArianeeNftsOwnedByThisUser = await arnClient.nft.arianee.getList();
```
