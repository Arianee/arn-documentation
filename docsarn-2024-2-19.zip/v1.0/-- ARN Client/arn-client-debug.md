---
title: "Debug"
slug: "arn-client-debug"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 09 2023 15:14:59 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Sep 07 2023 08:14:28 GMT+0000 (Coordinated Universal Time)"
---
The ARN Client provides the capability to issue debug messages about its internal behavior, aiding in understanding its functioning. The debug logging feature is exposed through the `log` property of the `arnClient` object.

## Accessing the Logger

To access the logger, use the following code snippet:

```javascript
arnClient.log
```

The `log` property provides an instance of the `ArnLogger`, which handles the debug logging functionality. By default, the ARN Client utilizes a built-in logger implementation, but you have the option to replace it with a custom implementation of your choice.

## Logger API

The logger API is similar to the logging API provided by the system's `console`, with the addition of a `name` field that serves as a prefix for log messages. The API allows you to log messages at different levels, such as `log`, `info`, `warn`, and `error`. Each log message can be associated with a specific name to identify the context or source of the log.

## Default Logger Implementation

The ARN Client's default logger implementation, known as `DefaultLogger`, has the following characteristics:

- It utilizes the prefix `"arn"` as the default `name` for log messages.
- Log messages are outputted to the console, using the system's `console` by default.
- By default, it outputs log messages at the `warn` and `error` levels. However, the logger's behavior can be configured to output log messages at other levels as well, depending on its configuration or the value of the `ARN_LOG_LEVEL` environment variable (if present).

## Sub-Loggers

If you require loggers for sub-contexts within the ARN Client (e.g., from the root "arn" logger or any other custom logger), you can create sub-loggers using the `fork()` method. The `fork()` method allows you to create a new logger instance that inherits the configuration and settings from its parent logger. Here's an example of how to create a sub-logger:

```javascript
mySubLogger = arnClient.log.fork('myOwnService');
```

In the above example, `mySubLogger` is a new logger instance created from the parent logger `arnClient.log`. The `fork()` method takes a string argument representing the name of the sub-context or service associated with the sub-logger.

By using sub-loggers, you can organize and differentiate log messages based on different contexts within the ARN Client, making it easier to debug and troubleshoot specific parts of the application.

Should you want to create loggers for sub-contexts (from the root “arn” logger or any other of your own), you can use the logger’s fork() method. For instance:

```javascript
mySubLogger = arnClient.log.fork('myOwnService');
```
