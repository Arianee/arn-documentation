---
title: "ARN Client ERC-721 Condition API"
slug: "condition-arn-client-erc-721-condition-api"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Jun 15 2023 12:44:36 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 28 2023 15:37:37 GMT+0000 (Coordinated Universal Time)"
---
The ARN Client Condition API provides convenient methods for checking conditions related to standard ERC721 non-fungible tokens (NFTs) through the `arnClient.condition.erc721` API.

## Checking Ownership

To check if the connected user owns regular ERC721 NFTs, you can use the `isOwnedFrom` method. Here's an example:

```javascript
const myContract = '0x776d77485578e703131b66ef50b1d77f225cc478';
const owns = await arnClient.condition.erc721.isOwnedFrom(myContract);
if (owns) {
  console.log(`The user owns at least one NFT from the required collection`);
} else {
  console.log(`The user does not own any NFT from the required collection`);
}
```

In the example above, `myContract` represents the address of the required collection. The method `isOwnedFrom` checks if the connected user owns any NFTs from the specified collection. If the user owns at least one NFT, it returns `true`; otherwise, it returns `false`.

## Adding More Details

If you need to be more specific, you can include additional details such as the blockchain network and the minimum count of NFTs required. Here's an example:

```javascript
const myContract = '0x776d77485578e703131b66ef50b1d77f225cc478';
const minCount = 2;
const myChain = 5; // Goerli
const owns = await arnClient.condition.erc721.isOwnedFrom(myContract, minCount, myChain);
if (owns) {
  console.log(`The user owns at least ${minCount} NFTs from the required collection`);
} else {
  console.log(`The user does not own enough NFTs from the required collection`);
}
```

In this example, `minCount` represents the minimum count of NFTs required from the collection, and `myChain` represents the blockchain network (Goerli in this case). The method `isOwnedFrom` will check if the connected user owns at least `minCount` NFTs from the specified collection on the specified blockchain network.

> 💡 This API is a convenience method built on top of the `HasERC721Condition` and allows you to benefit from cached results.
