---
title: "ARN Client User Condition API"
slug: "condition-arn-client-user-condition-api"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Jun 15 2023 12:45:33 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 28 2023 15:49:31 GMT+0000 (Coordinated Universal Time)"
---
The ARN Client Condition API provides several convenient APIs to check conditions related to the connected user/wallet. These conditions can be evaluated using the `arnClient.condition.user` API.

## Checking Being Listed

Lists in the ARN Server configuration can be defined and stored on the server side. The client conditions API allows you to check if the connected user/wallet is listed in specific lists using their symbolic names.

Here is an example of how to use the `isListedIn` function to check if the user is listed in multiple lists:

```javascript
const isListed = await arnClient.condition.user.isListedIn('myList1', 'myList2');
if (isListed) {
  console.log(`The user is listed in at least one of the checked lists`);
} else {
  console.log(`The user is not part of any of the required lists`);
}
```

> 💡 - The `isListedIn` function is a convenient API that internally uses the `IsWhitelistedCondition` API.
> - The condition API supports chaining, allowing you to use the `inContext(someConditionContext).isListed(lists)` syntax, which enables you to benefit from cached results.
