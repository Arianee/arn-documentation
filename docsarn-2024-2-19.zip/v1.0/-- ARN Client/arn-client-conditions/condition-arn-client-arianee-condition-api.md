---
title: "ARN Client Arianee Condition API"
slug: "condition-arn-client-arianee-condition-api"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Jun 15 2023 12:45:14 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Jul 24 2023 09:18:32 GMT+0000 (Coordinated Universal Time)"
---
The ARN Client Condition API provides convenient APIs to check conditions related to Arianee's NFTs, also known as "Arianee Smart Assets." These conditions can be evaluated using the `arnClient.condition.arianee` API.

## Checking Tags

The `hasNftWithTags` function allows you to check if the connected user owns Arianee Smart Assets (Arianee NFTs) that bear specific tags or none at all.

Here is an example of how to use the `hasNftWithTags` function to check if the user has NFTs with required tags:

```javascript
const hasTags = await arnClient.condition.arianee.hasNftWithTags('myTag1', 'myTag2');
if (hasTags) {
  console.log(`The user has NFTs with the required tags!`);
} else {
  console.log(`The user has no NFTs with the required tags`);
}
```

> 💡 - The `hasNftWithTags` function is a convenient API that internally uses the `HasArianeeSmartAssetCondition` API.
> - The condition API supports chaining, allowing you to use the `inContext(someConditionContext).hasTags(tags)` syntax, which enables you to benefit from cached results.

## Checking SPKZ Rules

The `isSpkzVerified` function allows you to check if a specific SPKZ rule is verified or not.

Here is an example of how to use the `isSpkzVerified` function to check if a server SPKZ rule is verified:

```javascript
const ok = await arnClient.condition.arianee.isSpkzVerified('myServerSpkzRule');
if (ok) {
  console.log(`The user owns at least 11 tokens`);
} else {
  console.log(`The user does not own enough tokens`);
}
```

> 💡 - The `isSpkzVerified` function is a convenient API that internally checks the verification of an SPKZ rule.
> - For more details about Token Gating rules, refer to the [ARN Client Condition API documentation](doc:arn-client-conditions).
