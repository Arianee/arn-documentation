---
title: "ARN Client HTTP Condition API"
slug: "condition-arn-client-http-condition-api"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Jun 15 2023 12:46:01 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 28 2023 15:49:15 GMT+0000 (Coordinated Universal Time)"
---
The ARN Client Condition API provides a convenient way to check conditions based on the result of an HTTP request. One of the APIs available is the `arnClient.condition.http` API, which allows you to perform HTTP calls and evaluate the response.

## Checking Request's Response

The `requestReturns(request, response)` function is used to send an HTTP request to the ARN server and verify if the response meets the expected conditions.

Here is an example of how to use the `requestReturns` function. In this case, an HTTP POST request is made to a specific server with a payload, and the condition being checked is that the `expired` property in the JSON response should be `false`:

```javascript
const returnedExpected = await arnClient.condition.http.requestReturns(
  {
    method: 'POST',
    url: 'https://some-server.com/some-route',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({someProp: 'Expected value'})
  },
  {
    status: 200,
    jsonPath: {
      path: '$.expired',
      value: false
    }
  }
);
```

> 💡 - The `requestReturns` function is a convenient API that internally uses the `IsWhitelistedCondition` API.
> - The condition API supports chaining, allowing you to use the `inContext(someConditionContext).requestReturns(req, res)` syntax, which enables you to benefit from cached results.
