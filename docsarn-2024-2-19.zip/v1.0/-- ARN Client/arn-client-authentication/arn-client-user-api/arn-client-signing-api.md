---
title: "ARN Client Signing API"
slug: "arn-client-signing-api"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Wed Oct 18 2023 07:46:11 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Oct 18 2023 08:26:44 GMT+0000 (Coordinated Universal Time)"
---
The ARN Client Signing API provides a range of secure message signing methods, allowing you to sign messages from both the client and server sides. This comprehensive documentation outlines how to effectively utilize these methods.

## Client/Wallet Signing

### Signing a Message

You can request the user to sign a text message using the `signMessage` function. This function is accessible via [`arnClient.auth.currentContext.signMessage(textMessage)`](https://arianee.github.io/arn/packages/arn-client/docs/classes/ArnAuthContext.html#signMessage), and it returns a Promise containing the signature string.

### Signing Typed Data

For signing structured data using the EIP-712 standard, you can employ the `signTypedData` function. This function is available through [`arnClient.auth.currentContext.signTypedData(domain, types, record)`](https://arianee.github.io/arn/packages/arn-client/docs/classes/ArnAuthContext.html#signTypedData). It returns a Promise with the signature string, just like other signing methods.

### Signing a Transaction

If you need the user's signature for a transaction, such as minting an asset, you can use the `signTransaction` function. Access it via [`arnClient.auth.currentContext.signTransaction(ethersTx)`](https://arianee.github.io/arn/packages/arn-client/docs/classes/ArnAuthContext.html#signTransaction), and it will return a Promise with the signature string.

### Signing an Access Token

Since version 1.45.4

You can also request the user to sign an Arianee JWT (AAT) using the `signAAT` function. This function can be found at [`arnClient.auth.currentContext.signAAT(jwtPayload, message?, separator?)`](https://arianee.github.io/arn/packages/arn-client/docs/classes/ArnAuthContext.html#signAAT). It returns a Promise that contains the signature string.

**Example: SPKZ SSO**

The AAT signing feature is valuable for implementing Single Sign-On (SSO) across various Arianee products. For instance, if you are wallet-connected and wish to follow a link to a SPKZ chat room without the need for reauthentication, consider the following code snippet:

```javascript
import { createOrRetrieveWallet } from '@arianee/spkz-sdk';

const SIGN_SEPARATOR =
      '\n\n\n\n\n\n\n The following is the technical part we need to know your actual wallet when you sign with your burner wallet \n';
const message = 'You need to sign an authorization for a burner wallet. This authorization allows you to send messages without having to sign each message. It\'s an offchain signature, and it's gas-free!';

const wallet = createOrRetrieveWallet();  // The wallet is a burner wallet, which will sign on behalf of a ledger wallet each time the user sends a message in SPKZ (for UX concerns)
const jwtPayload = wallet.wallets.getPayloadToSignToAddABlockchainWallet(arn.auth.currentContext!.status!.address!);
const signedJWT = await arn.auth.currentContext!.signAAT(jwtPayload, message, SIGN_SEPARATOR);
await wallet.wallets.addBlockchainWalletAuthorization(signedJWT);
wallet.wallets createAuthLink('https://spkz.io/app');

```
