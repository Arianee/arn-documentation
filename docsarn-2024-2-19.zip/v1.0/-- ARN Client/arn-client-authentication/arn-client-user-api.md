---
title: "ARN Client User API"
slug: "arn-client-user-api"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Wed Oct 18 2023 07:46:34 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Oct 18 2023 08:03:10 GMT+0000 (Coordinated Universal Time)"
---
The ARN Client User API is an essential part of the ARN Authentication API. Once initialized, the `arnClient` exposes its `ArnUserAuthService` through the `arnClient.auth.user` object.

This API empowers users to perform sign-in and sign-up actions using one of two methods:

- User/Password: This method requires a username and password combination. Password hashes are securely stored using the ARN Data Service.
- Magic Link: Users can sign in or sign up by clicking on a unique "magic link" sent via email.

## User/Password API

### User Info Structure

In the backend, user information is stored in accordance with the `ArnStoredUser` interface, which includes the following attributes:

- `id`: A generated UUID.
- `username`: The unique sign-in key (typically an email address).
- `passwordHash`: Used to verify the validity of the password.
- `credentials`: A list of credentials registered on devices, reserved for future WebAuthn support.

### Setup

To use the User/Password API, you need to perform two setup steps:

Declare the storage location for user data in the ARN server configuration.  
Ensure that the server can accept relevant remote calls, as failing to do so may result in receiving HTTP 403 errors.

### Sign Up

Here is an example of how to create a new user in the user database:

```javascript
const userInfo = await arnClient.auth.user.signup('jerome@arianee.org', 'mypass');
```

### Sign In

Logging in is similar to the signup API, but it will throw an error if the username and/or password is incorrect:

```javascript
const userInfo = await arnClient.auth.user.signin('[jerome@arianee.org](mailto:jerome@arianee.org)', 'wrongpass');
```

### Magic Link API

The Magic Link API enables users to sign in or sign up using a link that is sent to their email address.

### Setup

To use the Magic Link API, ensure you have:

1. Configured the magic link provider in your ARN project configuration for both the ARN server and ARN client.
2. Enabled the ARN server to accept the `/auth/user/sendMagicLink` remote call to avoid 403 HTTP errors. This is the default configuration for new projects, but existing projects should verify this.

### Sending the Link

To send a magic link to a user's email, use the following code:

```javascript
arnClient.auth.user.sendLink({
  email: 'jerome@arianee.org',
  type: 'signInOrUp',
});
```

In some cases, you may need to provide additional context to the link for more advanced actions, such as logging in and claiming an NFT. This can be achieved by including values for additional `params` supported by the link:

```javascript
arnClient.auth.user.sendLink({
  email: 'jerome@arianee.org',
  type: 'signInOrUp',
  params: {
    tokenId: 83995974,
    network: 'testnet',
    passphrase: 'b51q82xcbjke',
    autoclaim: true,
  },
});

```

Note that the params are customizable, as long as they are supported by the link generator and the app that handles the login link.

### Recognizing the Link

When a user clicks on the magic link in their mailbox, they will be redirected to your app's URL with a specific session "token." To recognize this token in your app's URL, use the following code:

```javascript
const token = arnClient.auth.user.getLinkToken(window.location.href);
if (token) {
  console.log('Found a magic link token!', token);
}
```

After recognizing the token, you can gather data on the logged-in user:

```javascript
const sessionInfo = await arnClient.auth.user.getLinkData(
  token, { session_duration_minutes: 1440 }
);
```
