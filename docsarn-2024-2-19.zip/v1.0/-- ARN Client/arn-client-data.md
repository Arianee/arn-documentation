---
title: "Data"
slug: "arn-client-data"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 09 2023 15:13:42 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Sep 07 2023 15:59:59 GMT+0000 (Coordinated Universal Time)"
---
The ARN Client provides a data service that allows you to upload or fetch data from the ARN Server. This service is optional and should be set up only if you need to read or write persistent data specific to your project. Once the ARN Client is initialized, the data service is exposed through the `data` property of the `arnClient` object.

## Configuration

The configuration of the data service is specified in the `data` section of the ARN Client configuration. The `data` section has the following property:

- `url`: The URL to connect to when accessing your project data. If left empty, the default URL of your ARN Server's data endpoint will be used. You can also specify a custom URL, either relative or absolute.

## Storing Data

To store data at the specified location in the data configuration, you can use various means of your choice. However, a convenient way to do so is by using the data update capability of the ARN Admin tool. You can use the web app version or the CLI version of ARN Admin to update the data.

## Fetching Data

To fetch data, you can call the `arnClient.data.get(dataQuery)` method, which returns a `promise` for retrieving the data specified by `dataQuery`. For example, if you want to fetch some feature flags from your project's data, you can use the following code:

```javascript
const features = await arnClient.data.get<MyFeatures>('/features');
if (features.someFeat) {
  displaySomeFeat();
}
```

In this example, `/features` is the data query that specifies the path to the stored feature flags.

## Filtering Data

If you want to select specific data from a collection before fetching the results, you can append a filter to the data query. For instance, if you want to fetch specific records from a `promocodes` collection based on a filter condition, you can use the following code:

```javascript
const promoCodesInfo = await arnClient.data.get<PromoCodeInfo[]>(
  `/promocodes?promocodes.tokenId=${nftId}`
);
```

In this example, `promocodes.tokenId=${nftId}` is the filter appended to the data query, which selects specific records from the `promocodes` collection based on the `tokenId` property matching the `nftId` value.
