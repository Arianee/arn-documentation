---
title: "Reporting"
slug: "arn-client-tracking"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 09 2023 15:13:54 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 28 2023 15:48:34 GMT+0000 (Coordinated Universal Time)"
---
The ARN Client provides the capability to perform various tracking operations. These operations involve reporting events such as page views or other custom events. Once the ARN Client is initialized, the tracking service is exposed through the `track` property of the `arnClient` object.

## Configuration

The configuration of the tracking service is specified in the `track` section of the ARN Client configuration. The `track` section allows you to set up multiple implicit tracking systems by providing an array of tracker configurations. The properties available in each tracker configuration are as follows:

- `arnTrackerType`: Specifies the type of tracker to be used. The possible tracker types include:
  - `google`: For Google Analytics tracking. In this case, an additional property `gtag` of type `GTag` is required.
  - `matomo`: For Matomo tracking. In this case, an additional property `trackingCode` of type `string` is required.
  - `sentry`: For Sentry tracking. In this case, additional properties `dsn` (of type `string`) and `tracesSampleRate` (of type `number`) are required.

## Notifying Events

To report explicit tracking information, you can use the relevant APIs provided by the ARN Client's tracking service. Here are the available methods:

- `arnClient.track.ctaClicked(ArnCtaEvent)`: Used to report that a call-to-action (CTA) was clicked. You can provide an `ArnCtaEvent` object containing relevant details about the clicked CTA.
- `arnClient.track.pageViewed(ArnPageViewEvent)`: Used to report that a page was viewed. You can provide an `ArnPageViewEvent` object containing information about the viewed page.
- `arnClient.track.report(ArnTrackedEvent)`: Used to report a custom tracked event. You can provide an `ArnTrackedEvent` object with custom event details.
