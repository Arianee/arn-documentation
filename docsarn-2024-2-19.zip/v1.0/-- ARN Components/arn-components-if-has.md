---
title: "arn-if-has"
slug: "arn-components-if-has"
excerpt: ""
hidden: false
metadata: 
  robots: "index"
createdAt: "Fri Jun 09 2023 15:10:33 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 28 2023 09:30:52 GMT+0000 (Coordinated Universal Time)"
---
The ARN If Has component allows you to check if the connected user owns NFTs that match certain criteria. There are two types of criteria that you can use: tags and ownership of NFTs from a specific collection.

## Tags

For Arianee Smart Assets (Arianee's NFTs), you can check if the NFT bears specific tag(s). Here's an example of how to use the component with tags:

```html
<arn-if-has tags="tag1,tag2">
  <div slot="if-false">
    You don't have the necessary tags.
  </div>
  <div slot="if-true">
    You own both tags!
  </div>
</arn-if-has>
```

Within the `<arn-if-has>` component, you can define HTML content within slots labeled as "if-false" and "if-true". The content in the respective slots will be displayed based on whether the user owns NFTs with the specified tags.

## Ownership

Starting from version 1.39.0, you can also check if the connected user owns NFTs from a regular ERC721 collection. Here's an example:

```html
<arn-if-has nft-from="0x776d77485578e703131b66ef50b1d77f225cc478">
  <div slot="if-false">
    You don't have any NFT from the required collection.
  </div>
  <div slot="if-true">
    You own at least one NFT from the required collection!
  </div>
</arn-if-has>
```

In this example, the `nft-from` attribute is used to specify the address of the ERC721 collection. The component will check if the connected user owns any NFTs from that specific collection and display the corresponding content in the "if-false" and "if-true" slots accordingly.

You can include any HTML content inside the slots, including other components, whether they are Angular components or web components (including other ARN Components). Additionally, you can add attributes to slots, such as `class` names, to customize the styling of the displayed content.

> 📌 The ARN If Has component relies on the connected user's wallet and the relevant NFT data. Make sure you have the necessary permissions and access to the required data in order to use this component effectively.

It is also possible to check if the connected user owns a NFT from regular ERC721 collection.

```html Example
<arn-if-has nft-from="0x776d77485578e703131b66ef50b1d77f225cc478">
  <div slot="if-false">
    You don't have any NFT from the required collection.
  </div>
  <div slot="if-true">
    You own at least one NFT from the required collection!
  </div>
</arn-if-has>
```
