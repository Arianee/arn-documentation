---
title: "Introduction"
slug: "arn-components-introduction"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 09 2023 14:31:54 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Jul 24 2023 09:15:33 GMT+0000 (Coordinated Universal Time)"
---
## What are ARN components?

ARN components are a set of ready-to-use web components. The use of widgets is nearly plug-n-play, no development is required from the Arianee tech team.

| Component                                           | Description                                                                                                     |
| :-------------------------------------------------- | :-------------------------------------------------------------------------------------------------------------- |
| [`arn-if`](doc:arn-components-arn-if)               | Shows and hides some HTML slots depending on conditions.                                                        |
| [`arn-if-connected`](doc:arn-components-if-connect) | Similar to `arn-if` but specialized for wallet connection. It allows you to check for wallet connection status. |
| [`arn-connect`](doc:arn-components-connect)         | Allows to add a wallet connection widget to a page.                                                             |
| [`arn-if-has`](doc:arn-components-if-has)           | Allows to check if the connected user owns some NFTs matching some criteria.                                    |
| [`arn-if-is`](doc:arn-components-if-is)             | Allows to check if the connected user/wallet matches some criteria.                                             |
