---
title: "arn-if-is"
slug: "arn-components-if-is"
excerpt: ""
hidden: false
createdAt: "Fri Jun 09 2023 15:10:42 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Feb 16 2024 15:53:13 GMT+0000 (Coordinated Universal Time)"
---
The ARN If Is component allows you to check if the connected user/wallet matches certain criteria. One of the criteria you can use is a whitelist, where you can check if the connected user's wallet is part of a list defined on the server side.

## Whitelist

Starting from version 1.39.0, you can use the ARN If Is component to check if the connected user's wallet is part of a specified list. 

```html
<arn-if-is listed-in="myList">
  <div slot="if-false">
    Sorry, you are not part of the members list.
  </div>
  <div slot="if-true">
    Welcome member!
  </div>
</arn-if-is>
```

Within the `<arn-if-is>` component, you can define HTML content within slots labeled as "if-false" and "if-true". The content in the respective slots will be displayed based on whether the connected user's wallet is listed in the specified list.

You can include any HTML content inside the slots, including other components, whether they are Angular components or web components (including other ARN Components). Additionally, you can add attributes to slots, such as `class` names, to customize the styling of the displayed content.

> 📌 The ARN If Is component relies on the server-side list and the connected user's wallet information. Make sure you have the necessary permissions and access to the server-side list data in order to use this component effectively.
