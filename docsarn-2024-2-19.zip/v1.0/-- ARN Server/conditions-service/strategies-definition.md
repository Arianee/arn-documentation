---
title: "Strategies Definition"
slug: "strategies-definition"
excerpt: "Define and send the strategy — list of requirements — you wish to apply so your users are allowed to access exclusive content."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Jun 29 2023 16:04:06 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Sep 04 2023 07:38:39 GMT+0000 (Coordinated Universal Time)"
---
## `erc-721-balance-of-issued-by`

Check if wallet(s) owns at least `n` NFT(s) issued by a specific address. It is used for Arianee ERC-721.

[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Description",
    "0-0": "Query param - `addresses`",
    "0-1": "Parameters are automatically retrieved by the API corresponding to the Ethereum wallet addresses that are being checked for ERC-721 tokens. The specific addresses are listed in the `addresses` array for each test case. This checks if specified wallet addresses have a certain minimum balance of ERC-721 tokens **issued by a specific address**, and if so, they are considered authorized.",
    "1-0": "`params`",
    "1-1": "Object with strategy parameters.",
    "2-0": "`minBalance`",
    "2-1": "Minimum owned tokens.",
    "3-0": "`address`",
    "3-1": "The wallet address of the issuer.",
    "4-0": "`tokens`",
    "4-1": "Tokens’ network information:  \n→ `chainId`  \n→ `network`  \n→ `address`",
    "5-0": "`issuer`",
    "5-1": "The specific issuer of the ERC-721 tokens will be checked in the wallet."
  },
  "cols": 2,
  "rows": 6,
  "align": [
    "left",
    "left"
  ]
}
[/block]


_In this example, the wallets must own at least 1 NFT on testnet issued by `0x135935c83aCF4E0C1Aa0BD948DC710eC76b478b0` to be authorized. _ 

```json Example:
[{
        name: 'erc-721-balance-of-issued-by',
        addresses: ['0x2361aBD3937d4f0D7ed72860aE39167B110B727e'],
        params: {
					// Have >= 1 NFT on testnet
          minBalance: '1',
          issuer: '0x135935c83aCF4E0C1Aa0BD948DC710eC76b478b0',     
          tokens: [{
            address: '0x512C1FCF401133680f373a386F3f752b98070BC5',
            chainId: '77',
            networkId: '1'
          }]
        }
      }]
```

## `erc-721-balance-of`

Check if wallet(s) owns at least `n` NFT(s).

[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Description",
    "0-0": "Query param - `addresses`",
    "0-1": "Parameters are automatically retrieved by the API corresponding to the Ethereum wallet addresses that are being checked for ERC-721 tokens. The specific addresses are listed in the addresses array for each test case. This checks if specified wallet `addresses` have a certain minimum balance of ERC-721 tokens, and if so, they are considered authorized.",
    "1-0": "`params`",
    "1-1": "Object with strategy parameters.",
    "2-0": "`minBalance`",
    "2-1": "Minimum owned tokens.",
    "3-0": "`address`",
    "3-1": "The wallet address of the issuer.",
    "4-0": "`tokens`",
    "4-1": "Tokens’ network information:  \n→ `chainId`  \n→ `network`  \n→ `address`"
  },
  "cols": 2,
  "rows": 5,
  "align": [
    "left",
    "left"
  ]
}
[/block]


_In this example, the wallets must own at least 1 NFT on polygon to be authorized._

```json Example:
[{
        name: 'erc-721-balance-of',
        addresses: ['0xF0245F6251Bef9447A08766b9DA2B07b28aD80B0'],
        params: {
          // Have >= 1 NFT on polygon
          minBalance: '1',
          tokens: [{
            address: '0x0a0bf65248805efa926c39bf51b6dd94e3d1a7af',
            chainId: '137',
            networkId: '1'
          }]
        }
      }]
```

## `erc-20-balance-of`

Check if wallet(s) owns at least `n` tokens. It can be a sum on multiple chains.

[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Description",
    "0-0": "Query param - `addresses`",
    "0-1": "Parameters automatically retrieved by the API corresponding to the Ethereum wallet `addresses` that are being checked for ERC-20 tokens on a specified blockchain network. This checks if specified wallet addresses have a certain minimum balance of ERC-20 tokens, and if so, they are considered authorized.",
    "1-0": "`params`",
    "1-1": "Object with strategy parameters.",
    "2-0": "`minBalance`",
    "2-1": "Minimum owned tokens.",
    "3-0": "`tokens`",
    "3-1": "Tokens’ network information:  \n→ `chainId`  \n→ `network`  \n→ `address`"
  },
  "cols": 2,
  "rows": 4,
  "align": [
    "left",
    "left"
  ]
}
[/block]


_In this example, the wallets must own at least 11 aria on mainnet to be authorized._

```json Example:
[[
        {
          name: 'erc-20-balance-of',
          addresses: ['0xb261d59bc5b2ced5c000ecb23783f3054e5fc5d0'],
          params: {
            minBalance: '11',
            tokens: [
              // Have >= 11 aria on mainnet
              {
                chainId: '1',
                networkId: '1',
                address: '0xedf6568618a00c6f0908bf7758a16f76b6e04af9'
              }

            ]
          }
        },
]]
```

## `opensea-collection-balance-of`

Check if wallet(s) owns at least `n` token(s) of an OpenSea collection.

[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Description",
    "0-0": "Query param - `addresses`",
    "0-1": "Parameters automatically retrieved by the API corresponding to the Ethereum wallet `addresses` that are being checked for ERC-20 tokens on a specified blockchain network. This checks if specified wallet addresses have a certain minimum balance of ERC-20 tokens, and if so, they are considered authorized.",
    "1-0": "`params`",
    "1-1": "Object with strategy parameters.",
    "2-0": "`minBalance`",
    "2-1": "Minimum owned tokens.",
    "3-0": "`tokens`",
    "3-1": "Tokens’ network information:  \n→ `chainId`  \n→ `network`  \n→ `address`"
  },
  "cols": 2,
  "rows": 4,
  "align": [
    "left",
    "left"
  ]
}
[/block]


_In this example, the wallets must own at least 1 token from the metaverse-avatars OpenSea collection to be authorized._

```json Example:
[{
        addresses: ['0x68b606a5172a91ec16e97620856ff732455157bc'],
        name: 'opensea-collection-balance-of',
        params: {
          minBalance: '1',
            collection: 'metaverse-avatars'
        }
      }]
    ]
```

## `erc-721-not-owner-of`

Check whether the specified wallet address does not own a specific ERC-721 NFT with a given token ID.

| Parameter                 | Description                                                                                                                                                                                                                                                                                                                                                       |
| :------------------------ | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Query param - `addresses` | Parameters are automatically retrieved by the API corresponding to the Ethereum wallet addresses that are being checked for ERC-721 tokens. The specific addresses are listed in the addresses array for each test case. This checks if specified wallet `addresses` have a certain minimum balance of ERC-721 tokens, and if so, they are considered authorized. |
| `params`                  | Object with strategy parameters.                                                                                                                                                                                                                                                                                                                                  |
| `contract`                | Ethereum address of the ERC-721 smart contract is being checked.                                                                                                                                                                                                                                                                                                  |
| `chainId`                 | Blockchain Identification Number.                                                                                                                                                                                                                                                                                                                                 |
| `tokenIds`                | Given tokens IDs that the wallet must not own.                                                                                                                                                                                                                                                                                                                    |

_In this example, the wallets must not own the tokens 92 & 100 on the specified blockchain._

```json Example:
{
      name: 'erc-721-not-owner-of',
      addresses: ['0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2'],
      params: {
        contract: '0x56c35dF413b3cd753f85427e55A8dF66A79f1bd7',
        chainId: '80001',
        tokenIds: [
          '92',
          '100'
        ]
      }
```

## `native-balance-of`

This strategy checks the balance of the native currency (Ether, Matic, etc…) in a wallet.

| Parameter                 | Description                                                                                                                                                                                                                                                          |
| :------------------------ | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Query param - `addresses` | Parameters are automatically retrieved by the API corresponding to the Ethereum wallet `addresses` on a specified blockchain network. This checks if specified wallet addresses have a certain minimum balance of tokens, and if so, they are considered authorized. |
| `params`                  | Object with strategy parameters.                                                                                                                                                                                                                                     |
| `minBalance`              | Minimum owned token.                                                                                                                                                                                                                                                 |
| `chainId`                 | Blockchain Identification Number.                                                                                                                                                                                                                                    |
| `networkId`               | Network Identification Number.                                                                                                                                                                                                                                       |

_In this example, the wallets must not own at least 10 tokens on mainnet._

```json Example:
[
        {
          name: 'native-balance-of',
          addresses: ['0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2'],
          params: {
            minBalance: '10',
            chainId: '1',
            networkId: '1'
          }
        }
      ]
```

## `erc-1155-balance-of-batch`

This strategy checks the balance of a batch of ERC-1155 fungible tokens held by a specific wallet address.

| Parameter                 | Description                                                                                                                                                                                                                                                                                                                                                         |
| :------------------------ | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Query param - `addresses` | Parameters are automatically retrieved by the API corresponding to the Ethereum wallet addresses that are being checked for ERC-1155 tokens. The specific `addresses` are listed in the addresses array for each test case. This checks if specified wallet addresses have a certain minimum balance of ERC-1155 tokens, and if so, they are considered authorized. |
| `params`                  | Object with strategy parameters.                                                                                                                                                                                                                                                                                                                                    |
| `chainId`                 | Blockchain Identification Number.                                                                                                                                                                                                                                                                                                                                   |
| `address`                 | Ethereum address of the account for which the ERC-1155 token balances are being retrieved.                                                                                                                                                                                                                                                                          |
| `minBalances`             | Minimum owned token.                                                                                                                                                                                                                                                                                                                                                |
| `id`                      | Token Identification Number of the batch.                                                                                                                                                                                                                                                                                                                           |
| `amount`                  | Amount of tokens owned by the wallet.                                                                                                                                                                                                                                                                                                                               |

_In this example, the wallet must own at least 200 references of the token ID 65542 and 2 references of the token ID 65541. _

```json Example:
    [
    {
      "name": "erc-1155-balance-of-batch",
      "addresses": ['0x20797F3D8b051f444Ed9968d34B0a6B1aF9c01d4'],

      "params": {
        "chainId": "1",
        "address": "0x7DaEC605E9e2a1717326eeDFd660601e2753A057",
        "minBalances": [
          { "id": "65542", "amount": "200" },
          { "id": "65541", "amount": "2" }
        ]
      }
    }
  ]


```

## `is-exact-address`

This strategy simply checks if a specified wallet address is exactly equal to a given address.

| Parameter                 | Description                                                                                                                                                                                             |
| :------------------------ | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Query param - `addresses` | Parameters are automatically retrieved by the API corresponding to the Ethereum wallet addresses that are being checked. The specific addresses are listed in the `addresses` array for each test case. |
| `params`                  | Object with strategy parameters.                                                                                                                                                                        |
| `addresses`               | Authorized wallet addresses.                                                                                                                                                                            |

_In this example, the wallet must be referenced in the `addresses` list. _

```json Example:
[{
        name: 'is-exact-address',
        addresses: ['0xF0245F6251Bef9447A08766b9DA2B07b28aD80B0'],
        params: {
          addresses: [
            '0x0a0bf65248805efa926c39bf51b6dd94e3d1a7af',
            '0xeFeA1123d4Ed5d342f429049Aa014bF628d10108'
          ]
        }
      }]
```

## `poap-holder-of`

This strategy checks whether a specified wallet address holds a POAP with a specified drop.

| Parameter                 | Description                                                                                                                                                                                             |
| :------------------------ | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Query param - `addresses` | Parameters are automatically retrieved by the API corresponding to the Ethereum wallet addresses that are being checked. The specific `addresses` are listed in the addresses array for each test case. |
| `params`                  | Object with strategy parameters.                                                                                                                                                                        |
| `eventId`                 | Drop Event Identification Number.                                                                                                                                                                       |

_In this example, the addresses must own a POAP from drop 14629. _

```json Example:
[
      {
        name: 'poap-holder-of',
        addresses: [
          '0xce7e15acf3da916a4df4842c3350248ad74ffc79',
          '0x9cE08276311e4c620Fb5b4DDb4b5156EED3fD743',
          '0x0F59576DE893Fb93Dd25d6a4fc6dB088FB2347D2'],
        params: {
          eventId: '14629'
        }
      }
    ]
```

## `room-owner`

This strategy checks whether a specified wallet address is the owner of a specific room.

| Parameter                 | Description                                                                                                                                                                                             |
| :------------------------ | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Query param - `addresses` | Parameters are automatically retrieved by the API corresponding to the Ethereum wallet addresses that are being checked. The specific `addresses` are listed in the addresses array for each test case. |
| `params`                  | Object with strategy parameters.                                                                                                                                                                        |
| `chainId`                 | Blockchain Identification Number.                                                                                                                                                                       |
| `networkId`               | Drop Event Identification Number.                                                                                                                                                                       |

_In the example, the owner must own the specified room._

```json Example:
[{
        name: 'room-owner',
        addresses: ['0xeFeA1123d4Ed5d342f429049Aa014bF628d10108'],
        params: {
          chainId: '80001',
          networkId: '1'
        }
      }]
    ]
```

## `unlock-has-membership`

This strategy checks whether a specified wallet address has an active membership for a particular lock in the Unlock protocol.

| Parameter                 | Description                                                                                                                                                                                             |
| :------------------------ | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Query param - `addresses` | Parameters are automatically retrieved by the API corresponding to the Ethereum wallet addresses that are being checked. The specific `addresses` are listed in the addresses array for each test case. |
| `params`                  | Object with strategy parameters.                                                                                                                                                                        |
| `chainId`                 | Blockchain Identification Number.                                                                                                                                                                       |
| `lockAddress`             | Address of the Unlock contract.                                                                                                                                                                         |

_In this example, the wallet must have an active membership on the specified lock address in the Unlock protocol._

```json Example:
[
      {
        name: 'unlock-has-membership',
        addresses: [
          '0x9cE08276311e4c620Fb5b4DDb4b5156EED3fD743',
          '0x0F59576DE893Fb93Dd25d6a4fc6dB088FB2347D2'],
        params: {
          chainId: '4',
          address: lockContract
        }
      }
    ]]
```

## `api-balance-of`

This strategy checks NFT parameters. The strategy combines an API request to get information and authorize, or not, the specified wallet.

| Parameter                 | Description                                                                                                                                                                                             |
| :------------------------ | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Query param - `addresses` | Parameters are automatically retrieved by the API corresponding to the Ethereum wallet addresses that are being checked. The specific `addresses` are listed in the addresses array for each test case. |
| `params`                  | Object with strategy parameters.                                                                                                                                                                        |
| `url`                     | Endpoint of the API.                                                                                                                                                                                    |
| `headers`                 | API Authentification.                                                                                                                                                                                   |

_In example 1, the wallet must be whitelisted in my database. Return set [true] if whitelisted in the database, otherwise \[]._

```json Example 1:
{
      name: 'api-balance-of',
      addresses: ['0xabcdef', '0xghijkl'],
      params: {
        url: 'https://myurl.com/whitelist/__ADDRESS__', // The request takes the first address 
        // The API is called and should return an array
        headers: { 
					Authorization: 'Basic 123' },
	        minBalance: '1'
      }
    };
```

_In example 2, the wallet must have bought 5 items in my e-store. The API could return ['item1','item2','item3','item4','item5'], otherwise \[] if no purchase._

```json Example 2:
{
      name: 'api-balance-of',
      addresses: ['0xabcdef', '0xghijkl'],
      params: {
        url: 'https://myurl.com/customersPurchases/__ADDRESS__', // The request takes the first address 
        // The API is called and should return an array
        headers: { 
					Authorization: 'Basic 123' },
	        minBalance: '5'
      }
    };
```
