---
title: "Strategies Combinations"
slug: "strategies-combinations"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Jun 29 2023 16:04:46 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Sep 04 2023 07:38:52 GMT+0000 (Coordinated Universal Time)"
---
## Introduction

When setting up a strategy with multiple requirements, you can choose: 

- **AND** - The wallet needs to comply with both
- **OR** - The wallet needs to comply with either one

> 📌 For specific strategies, the sum — **TOTAL**  — of a wallet's required tokens can be required to respect the `minBalance`, and thus respect the strategy.  
> Example: `erc-20` to make sum of bridged `erc-20` on different networks.

Also, types of strategy management can adapted to give flexibility to the strategy definition. It is possible to combine multiple strategies and make very fine tuning token gated strategies. The first-level table elements are **OR** requirements. The second-level table elements are **AND** requirements. You can combine any of the mentioned requirements.

## Use Case

_The user might need to own more than 10 Aria **AND** have 1 Bored Ape NFT, **OR** own more than 10 Matic **AND** more than 3 Ethers, **OR** own 2 CryptoPunks NFTs **AND** 1 specific POAP NFT to access the said exclusive content._

```text Example:
[ 
		 [ own more than 10 aria AND own 1 bored ape NFT ] 
	OR [ own more than 10 matic AND own more than 3 ethers ] 
	OR [ own 2 CryptoPunks NFT AND own 1 specific POAP NFT ]
]
```

→ Each set of requirements is like a table with two levels. The first level is made up of **OR** requirements, which means you only need to meet one of those requirements to be allowed access. The second level is made up of **AND** requirements, which means you need to meet all of those requirements to be allowed access.
