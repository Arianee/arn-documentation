---
title: "What is Token Gating?"
slug: "what-is-token-gating"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Jun 29 2023 16:01:59 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Sep 04 2023 07:38:01 GMT+0000 (Coordinated Universal Time)"
---
## Introduction

Token gating is a popular marketing strategy to build community, promote the adoption of new tokens, reward loyal users, and generate revenue.

As a brand, you want your audience to access exclusive content if they meet specific rules and requirements.

_e.g. If the user has a minimum of 1 NFT minted from a brand, then the user can access exclusive private sales._

Token gating is a permissions mechanism used in blockchain-based systems to control access to certain features or resources. With token gating, access to restricted areas or features is granted only to users who hold a specific token or set of tokens. By using token gating, blockchain-based services can provide permission access control, ensuring that only authorized users can access restricted areas or features. 

## API service

In this section, we introduce an API service that allows you to easily implement token-gating rules and check whether a given address is authorized to access specific features or resources.

Token Gating As A Service proposes to combine multiple requirements and verify compliance with the wallet through a simple API.

The rules, called strategy, are represented as nested arrays that define various conditions that must be met for access to be granted. Each nested array contains a set of conditions connected by logical operators such as AND and OR.

For more information, refer to [Strategies Definition](doc:strategies-definition) and dig deeper into [Strategies Combinations](doc:strategies-combinations).
