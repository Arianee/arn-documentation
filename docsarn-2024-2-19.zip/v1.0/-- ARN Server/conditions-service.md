---
title: "Conditions Service"
slug: "conditions-service"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 09 2023 15:08:15 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Sep 04 2023 07:37:00 GMT+0000 (Coordinated Universal Time)"
---
The ARN Server includes and exposes a condition API that allows you to check if the connected user meets certain conditions. These conditions can include the ownership of Arianee NFTs with specific tags, membership in whitelists, or a combination of both.

> 💡 For more information, about conditions, dig deeper into [Token Gating.](doc:what-is-token-gating)

## Configuration

To configure the condition API, you need to specify the data service configuration where the conditions will be stored. This configuration is defined in the `condition` section of the ARN server configuration.

Example configuration to store conditions data under the `condition` path of an `arn_data` collection in a local MongoDB `test` database:

```json
"data": {    
   "uri": "mongodb://myMongoServer/myDb",    
   "collection": "arn_data",    
   "path": "condition"  
}
```

## Examples of conditions

### Whitelists

Whitelists are one type of condition data that can be stored using the ARN Server. Whitelists contain wallet IDs of users who are allowed to meet certain conditions.

The expected data structure for a whitelist is as follows:

- _whitelist name_
  - `whitelist`: an array of wallet IDs.

Example whitelist data stored under the `condition` path of the `arn_data` collection:

```json
{
  "isInMyList": {
    "whitelist": [
      "0x836345E2b1FF27fdAa2Cf9440A4F29a4f0Dd641a", 
      "0x836345E2b1FF27fdAa2Cf9440A4F29a4f0Dd641b"
    ]
  }
}
```

### ERC-721

NFT ownership check criteria can be specified from both the client side and the server side. If specified on the server side, the request should mention the name of the condition to be checked.

Example server-side NFT ownership condition stored under the `condition` path of the `arn_data` collection:

```json
{
  "serverSideOwnsAtLeastOneOfMyNFTs": {
    "chainId": 1,
    "contractAddress": "0x776d77485578e703131b66ef50b1d77f225cc478",
    "minBalance": 1
  }
}
```

## Conditions Usage

To execute server-defined Arianee's Token Gating rules, you need to define a Token Gating server to send SPKZ requests to. This is done in the `spkz` section of your project's configuration.

Example Token Gating server configuration:

```json
"spkz": {
  "url": "http://mySpkzServer",
  "apiKey": "mySpkzApiKey"
}
```

If you want the Token Gating rule to be stored on the server-side and invoked by the client using its name, you need to define the conditions strategies under the `condition` path of the `arn_data` collection in your database.

Example server-side Token Gating rule stored under the `condition` path of the `arn_data` collection:

```json
"myServerSpkzRule": {
  "strategies": [
    [      
      {        
        "name": "erc-20-balance-of",        
        "params": {          
          "minBalance": "2",          
          "tokens": [            
            {              
              "chainId": "1",              
              "networkId": "1",              
              "address": "0xedf6568618a00c6f0908bf7758a16f76b6

 
```

```json
"spkz": {
  "url": "http://mySpkzServer",  
  "apiKey": "mySpkzApikey"
}
```

If you want the rule to be stored on server-side and invoked by the client just by its name, the conditions strategies under the `condition` path of the `arn_data` collection of your database:

```json
"myServerSpkzRule": {
  "strategies": [
    [      
			{        
				"name": "erc-20-balance-of",        
				"params": {          
					"minBalance": "2",          
					"tokens": [            
						{              
							"chainId": "1",              
							"networkId": "1",              
							"address": "0xedf6568618a00c6f0908bf7758a16f76b6e04af9"            
						}          
					]        
				}      
			}    
		]  
	]
}
```
