---
title: "Configuration Management"
slug: "arn-server-configuration"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 09 2023 15:05:43 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Sep 11 2023 12:32:30 GMT+0000 (Coordinated Universal Time)"
---
The ARN Server is a powerful tool designed to manage the configuration of one or more projects. It utilizes the `arn_config` collection within its associated MongoDB database to store project-specific information. 

## Configuration Components

Each project configuration consists of the following components:

- `projectKey`: This serves as a unique identifier for your project.

- `projectConf`:
  - `client`: Contains the configuration settings for an ARN Client specific to the project.
  - `auth`: Includes the configuration details for authentication-related services.
  - `data`: Stores the configuration of the project's data service.
  - `i18n`: Manages the configuration settings for the Internationalization service.
  - `condition`: Holds the configuration details for the condition service.
  - `nmp`: Specifies the configuration settings for the NFT Management Platform used to check NFT and token-gated conditions (typically through tags):
    - `url`: The URL of the NFT Management Platform to establish a connection.
    - `apiKey`: The API key required to authenticate with the NFT Management Platform.
  - `spkz`: Stores the configuration details for the Token Gating as a Service.

## Project Management

To manage the configuration of your project within the ARN Server, you have several options:

1. **Issuing HTTP Requests**: You can create or update the project configuration by issuing HTTP requests according to the REST API provided. Please refer to the API documentation for detailed instructions.

2. **ARN Admin Tool**: The ARN Admin tool offers a user-friendly interface to access and edit the `projectConf` configuration, as well as managing data storage associated with your project.

3. **Direct Database Update (Not Recommended)**: Although possible, it is not recommended to directly update the database. This method should be used cautiously and only if no other options are available.

We strongly encourage utilizing the REST API or the ARN Admin tool to manage your project configuration. This ensures data integrity, compatibility with the ARN Server, and a streamlined management process.

Choose the approach that best suits your requirements, and enjoy the benefits of efficient project configuration management with the ARN Server.
