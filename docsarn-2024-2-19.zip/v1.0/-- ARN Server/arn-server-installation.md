---
title: "Installation"
slug: "arn-server-installation"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 09 2023 14:51:56 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Jul 24 2023 07:28:08 GMT+0000 (Coordinated Universal Time)"
---
## Setup

To get started with the ARN Server, follow these steps:

1. Check out the repository.
2. Set up a .env file in the project root directory. Here's an example of the .env file configuration:

```
# Configuration database
MONGO_URI=mongodb://mydbserver:27017/arn

# API key to create new projects
ARN_ROOT_ADMIN_API_KEY=Sup3rR00t4dm1n
```

3. Install the required packages by running npm install.
4. Build the code by running npm run build.
5. To run the server, execute one of the following NPM scripts:

- npm run starts to execute the built code.
- npm run dev: start for development.

> 📌 For server configuration options, refer to the ARN Server Configuration documentation.

## REST API

While it is recommended to access the ARN Server through an ARN Client, you can also interact with the server directly via its REST API.

### Projects List

`GET /` - Retrieves the keys of projects hosted by this server.

### Project-Specific Routes

These routes are processed in the context of a specific project and begin with /:projectKey in the URL:

`GET /:projectKey `- Retrieves the project configuration. Requires root admin authorization to return the full project configuration; otherwise, it returns the client configuration by default.

`POST /:projectKey` - Creates a new project configuration. Expects the project configuration JSON in the request body and requires root admin authorization.

`PUT /:projectKey` - Updates an existing project configuration. Expects the updated project configuration JSON in the request body and requires either a project admin or root admin authorization.

`DELETE /:projectKey` - Deletes an existing project configuration. Requires either a project admin or root admin authorization.

Please refer to the relevant authorization documentation for more details on project and root admin authorization.

That covers the basic usage of the ARN Server's REST API. Feel free to explore and leverage these routes to manage your projects effectively.
