---
title: "Data"
slug: "arn-server-data"
excerpt: ""
hidden: false
metadata: 
  robots: "index"
createdAt: "Fri Jun 09 2023 15:06:10 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 28 2023 09:18:56 GMT+0000 (Coordinated Universal Time)"
---
The ARN Server includes and exposes a data API that allows you to upload and fetch data with a filter. This service is optional and should be set up only if you need to read/write persistent data specific to your project.

## Configuration

To configure the data service, you need to specify the following properties:

- `uri`: The location from where the data is fetched. If the value starts with `mongodb:` or `mongodb+srv:`, you must also provide the following fields at the same level as the `uri` property:
  - `collection`: The name of the MongoDB collection where the data is stored (e.g., "arn_data").
  - `path`: The path in the collection where the data is located.

For example, to store data under the root path ("/") of an "arn_data" collection in a MongoDB database, the configuration would be:

```json
"data": {
  "uri": "mongodb+srv://maxime:*********@kelpie-prod.ugfjp.mongodb.net/arn-server-test-dev",
  "collection": "arn_data",
  "path": "/"
}
```

> 📌 Note that an ARN Server can instantiate multiple data services. Each service can be used to store different types of data such as translations, conditions, feature flags, or any other data you need to read/write. Each data service requires its own specific configuration, which can target the same database/collection or a different one each time.

## REST API

The data API provides the following endpoints:

- `GET /:projectKey/data/:path?filter`: Fetches data based on the specified path and optional filter. This route requires a project user authorization.
- `POST /:projectKey/data/:path?overwrite=true`: Sends or updates data at the specified path. The `overwrite=true` parameter indicates whether the existing data at the path should be overwritten. This route requires a project user authorization.

Please note that data access can be restricted through ACL configuration, similar to other remote APIs.

> 💡 You can use the ARN Admin tool to upload data easily.
