---
title: "CLI tool"
slug: "arn-admin-cli-tool"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 09 2023 14:51:12 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Sep 04 2023 07:40:07 GMT+0000 (Coordinated Universal Time)"
---
> ⚠️ While it is technically possible to directly access and modify project data in the relevant database, we strongly discourage this approach. Direct database access can result in writing incorrect data and missing the application of essential business rules, such as cache invalidation. To ensure data integrity and consistency, we recommend using the ARN Server administration commands and options outlined in this documentation.

## Commands

### Root Commands

These commands apply to the ARN Server and all projects hosted on it. Root API key authorization is required to execute these commands.

#### Projects Listing

To list existing project keys, use the following command:

```bash
ts-node ArnAdminTool .* --url https://my-arn-server --api-key MyApiKey
```

Example output:

```bash
Project keys:
[ 'testProject', 'yslbeauty' ]
```

You can refine the filter by specifying a regular expression:

```bash
ts-node ArnAdminTool ysl.* --url https://my-arn-server --api-key MyApiKey
```

Example output:

```bash
Project keys:
[ 'yslbeauty' ]
```

#### Projects Migration

This command migrates all projects hosted on the ARN Server. It applies the migration specified by the migration command.

```bash
ts-node ArnAdminTool migrate ./MigrationCommand_202302131854 --url https://my-arn-server --api-key MyApiKey
```

### Project Commands

These commands require a project API key (or root API key).

#### Project Fetch

To fetch the configuration of a specific project, use the following command:

```bash
ts-node ArnAdminTool --url https://my-arn-server --api-key MyApiKey
```

Example output:

```json
Project yslbeauty config is:
{
  "projectAdminApiKey": "MyApiKey",
  "client": {
    "i18n": {
      "lang": [
         "en",
         "fr"
      ],
    "default": "en"
   },
  ...
}
```

You can combine the fetch command with the `--file` option to save the fetched configuration into a file.

#### Project Update

To update the configuration of a project, use the following command:

```bash
ts-node ArnAdminTool --project myproject --update --file newConfig.json --url https://my-arn-server --api-key MyApiKey
```

This command prompts you to confirm the overwrite and then updates the project:

```bash
Update project "myproject" from https://my-arn-server? **y**
Updated project myproject
```

#### Project Migration

This command executes a migration code that mutates the configuration state of a project.

```bash
ts-node ArnAdminTool migrate ./MyMigration --project myproject --url https://my-arn-server --api-key MyApiKey
```

The specified migration implements the `MigrationCommand` interface:

```tsx
export default class MyMigration implements MigrationCommand {
  constructor(protected http: HttpService, protected logger: Logger) {}
  async execute(configService: ProjectConfigService) {
    // Migration implementation using configService.get()/set()
  }
}
```

The migration is dynamically loaded, and its `execute()` method is called.

### Data Commands

Data commands require the `--data` command.

#### Data Import

You can import data using the `--import` option in combination with the data command.

To import data from specific columns (`column1` and `column2`) of a CSV file into a given data path:

```bash
ts-node ArnAdminTool --project my
```
