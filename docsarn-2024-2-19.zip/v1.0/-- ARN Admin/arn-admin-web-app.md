---
title: "Web app"
slug: "arn-admin-web-app"
excerpt: ""
hidden: false
metadata: 
  robots: "index"
createdAt: "Fri Jun 09 2023 14:51:17 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 28 2023 09:19:53 GMT+0000 (Coordinated Universal Time)"
---
## ARN Admin Web App

The ARN Admin web app is one of the tools available for administrating an ARN Server and its hosted projects. You can access the web app at [https://arn-admin.netlify.app](https://arn-admin.netlify.app/).

### Adding a Server

To connect to an existing ARN Server, follow these steps:

1. Open the ARN Admin web app.
2. Click on the "Add server" button located at the bottom right of the app.

![Add server button](https://files.readme.io/7545182-1Untitled.png)

3. A popup will appear, allowing you to enter the ARN Server URL and an API key for accessing the administration API routes. The API key can be either a project's administrator API key or a server administrator API key. Server administrators have the additional privilege of creating new projects.

![Add server popup](https://files.readme.io/ff8c6f0-Untitled2.png)

> 💡 Once added, the server URLs and API keys you enter will be remembered.

4. If the URL and API key are correct and match, the server will appear in the list. It will display the number of projects hosted on that server.

![Server list](https://files.readme.io/1646ad1-Untitled3.png)

### Administrating a Server

To view the list of projects hosted by a server, click on the server name to expand its details.

![Expanded server details](https://files.readme.io/b826893-Untitled4.png)

To view the details of a specific project, click on the project name. It will display the project's configuration and data.

![Project details](https://files.readme.io/32f67af-Untitled5.png)

#### Configuration Administration

To edit a project's configuration, click on the project name to expand it. An editor will be displayed, allowing you to modify the configuration in RAW JSON format.

The "Export" and "Update" buttons are available for saving the configuration to a file (as a backup) and updating the project's configuration on the server, respectively.

![Configuration editor](https://files.readme.io/adc1167-Untitled6.png)

#### Data Administration

To edit a project's data, click on the project name to expand it. A filtering form and an editable fetch result will be displayed.

![Data editor](https://files.readme.io/f0f4df6-Untitled7.png)

To fetch data, submit a filter by entering the desired filter syntax (`some/path?some.path.field=value`) and hit return or click the "Fetch" button.

> 💡 Filters are expected to comply with the specified syntax. For example: `i18n/fr/auth?i18n.fr.auth.notifContentSigError=La signature n'est pas valide`.

The fetched data will appear in the raw JSON editor. You can edit the data and click either "Export" or "Update" to send a modified version to the server.

![Raw JSON editor](https://files.readme.io/0de0f29-Untitled8.png)

> 📌 - Leaving the filter empty will retrieve all available data.
> 
> <!---->
> 
> - You can create new data by specifying its desired location (collection path) in the filter, entering a value, and clicking the "Update" button.

#### Conditions Data

ARN allows conditions to be stored in any MongoDB database, but they are usually stored in a `condition` collection within a project's data. You can review or

 edit/update such conditions by specifying the appropriate condition filter.

For example, here is how a whitelist condition can be parameterized:

![Whitelist condition](https://files.readme.io/a503d8c-Untitled9.png)

#### Internationalization Data

ARN allows translations to be stored in any MongoDB database, but they are typically stored in an `i18n` collection within a project's data. You can review or edit/update these translations by specifying the appropriate i18n filter.

![Internationalization data](https://files.readme.io/b3c6ea2-Untitled10.png)

## Other Administration Tools

In addition to the ARN Admin web app, there are other tools available for administrating an ARN Server and its projects. These tools provide command-line interfaces (CLIs) to perform various administrative tasks.

Please refer to the previous section titled "Commands" for detailed information on using these tools and their available commands and options.

> 📌 The ARN Admin web app is just one of the possible tools for administrating an ARN Server and its projects. It provides a user-friendly graphical interface, while the command-line tools offer more flexibility and automation capabilities. Choose the tool that best suits your requirements and preferences.
