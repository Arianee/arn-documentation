---
title: "Introduction"
slug: "arn-admin-introduction"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 09 2023 14:31:45 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 30 2023 10:07:08 GMT+0000 (Coordinated Universal Time)"
---
Welcome to the documentation for ARN Server project administration! This guide will walk you through the recommended methods for editing an ARN project configuration and provide details on the available administration APIs.

While it is technically possible to directly access the relevant database to read or update project data, we strongly discourage this approach. Direct database access carries the risk of writing incorrect data and bypassing important business rules, such as cache invalidation. To ensure the integrity of your project and maintain consistency, we recommend using the ARN Server administration APIs.

## ARN Server Configuration

The ARN Server stores the server configuration, including data, internationalization (i18n), security settings, and more. The server configuration consists of:

- **Client Configuration**: This configuration is typically fetched from the front end of your application and contains client-specific settings.
- **Project Data**: The project's data is stored within the server configuration.

## Administration API Options

You have multiple options for interacting with the ARN Server administration APIs:

- **REST API Calls**: You can make HTTP requests to the ARN Server administration endpoints. To access these APIs, you need to provide a valid administrator API key for authentication.
- ** [ARN Admin CLI Tool](doc:arn-admin-cli-tool)**: The ARN Admin Command-Line Interface (CLI) tool provides a command-line interface for managing and editing project configurations. The CLI tool offers a convenient way to interact with the ARN Server administration APIs from your terminal.
- ** [ARN Admin Web App](doc:arn-admin-web-app)**: The ARN Admin Web Application provides a user-friendly web-based interface for managing ARN project configurations. You can access and edit project settings, data, and other related components through the web app.

Choose the method that best suits your workflow and preferences to effectively manage and update your ARN project configuration.
