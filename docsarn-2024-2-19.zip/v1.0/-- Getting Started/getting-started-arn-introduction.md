---
title: "What is ARN?"
slug: "getting-started-arn-introduction"
excerpt: "This page will help you get started with ARN. Discover and dig deeper into ARN services."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 09 2023 14:16:55 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Sep 11 2023 12:27:34 GMT+0000 (Coordinated Universal Time)"
---
## Our mission

Arianee's mission is to build perpetual relationships between brands and customers based on trust, privacy, and transparency. We build blockchain protocols and SaaS products to connect users and brands with digital assets: the decentralized internet's zero-party data.

## What's ARN?

The name derived from _ARiaNee_, ARN is a set of client-side JavaScript libraries connecting with a remote server to provide web3 services about both standard (ERC 721) and Arianee-specific (check Arianee NFT tags, etc.) assets.

- 💽 [**ARN Server**](doc:arn-server-introduction): Set up and administrate an ARN Server and configure your brand's project on this server. 
- 🔑 [**ARN Admin**](doc:arn-admin-introduction): Set up tools to administrate the control of your server.
- 🧩 [**ARN Components**](doc:arn-components-introduction): Set of ready-to-use web3 components. 
- 🪄 [**ARN Client**](doc:arn-client-introduction): JavaScript APIs to include in your website to leverage Arianee web3 services.

## ARN Architecture

![](https://files.readme.io/3ced49c-ARN_Architecture.png)

## What are the use cases?

**Authentication**

- Auto authentification for claiming on an external website.
- Auto users’ authentification to SPKZ brand’s room.

**Token Gating**

- Key to exclusive content for end-users.
- Loyalty program for customers with rewards.

**Retrieve NFTs information**

- Display a list of NFT collections helps in a connected wallet.
